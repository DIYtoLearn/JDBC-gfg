package com.gl.magicofbooks.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
@Table(name="tbl_books")
public class Book
{
	@Id
	@Column(nullable=false)
	private int bookId;
	private String bookName;
	private String bookAuthor;
	private String publisherName;
	private String genre;
	private int bookPrice;
}
