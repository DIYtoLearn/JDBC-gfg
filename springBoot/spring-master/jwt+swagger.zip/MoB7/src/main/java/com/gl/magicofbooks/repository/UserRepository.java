package com.gl.magicofbooks.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gl.magicofbooks.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>
{
	@Query("SELECT u.uid,u.role FROM User u WHERE u.userName = ?1 and u.password = ?2")
	Object[] findUserbyuserNameAndpassword(String userName,String password);
	
	
}
