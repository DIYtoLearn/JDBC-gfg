package com.gl.magicofbooks.utility;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.gl.magicofbooks.exceptions.ResourceNotFoundException;

@RestControllerAdvice
public class ExceptionControllerAdvice
{
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorInfo> exceptionHandler(ResourceNotFoundException exp)
	{
		ErrorInfo error = new ErrorInfo();
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		error.setErrorMessage(exp.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<ErrorInfo>(error,HttpStatus.NOT_FOUND);
	}
}
