package com.gl.magicofbooks.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gl.magicofbooks.entity.User;
import com.gl.magicofbooks.service.UserService;

@RestController
public class UserController
{
	@Autowired
	UserService userService;
	
	@PostMapping("/login")
	public Object[] userLogin(@RequestParam("userName") String userName,
			@RequestParam("password") String password)
	{
		return userService.validateUser(userName, password);
	}
	
	@PostMapping("/register")
	public User Register(@RequestParam("userName") String userName,
			@RequestParam("password") String password,
			@RequestParam("email") String email,
			@RequestParam("role") String role)
	{
		User user = User.builder().userName(userName).email(email)
				.password(password).role(role).build();
		return userService.registerUser(user);
	}
}
