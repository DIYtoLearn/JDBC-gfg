package com.gl.magicofbooks.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.magicofbooks.entity.User;
import com.gl.magicofbooks.repository.UserRepository;

@Service
public class UserService
{
	@Autowired
	private UserRepository userRepository;
	
	public Object[] validateUser(String userName,String password)
	{
		
		Object[] userDetails = userRepository.findUserbyuserNameAndpassword(userName,password);
		return userDetails;
	}
	
	public User registerUser(User user)
	{
		return userRepository.save(user);
	}
	
}
