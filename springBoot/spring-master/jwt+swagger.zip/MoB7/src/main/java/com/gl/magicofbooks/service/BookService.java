package com.gl.magicofbooks.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import com.gl.magicofbooks.entity.Book;
import com.gl.magicofbooks.exceptions.ResourceNotFoundException;
import com.gl.magicofbooks.repository.BookRepository;

@Service
public class BookService
{
	@Autowired
	BookRepository bookRepository;
	
	public Book addBook(Book book)
	{
		return bookRepository.saveAndFlush(book);
	}
	
	public Book getBookById(int bid) throws ResourceNotFoundException
	{
		// TODO Auto-generated method stub
		Optional<Book> book= bookRepository.findById(bid);
		if(book.isEmpty())
			throw new ResourceNotFoundException("Book Not Found with Id "+bid);
		else
			return book.get();
	}
	
	public Book updateBook(int bid,int bookPrice) throws ResourceNotFoundException
	{
		Book book = getBookById(bid);
		book.setBookPrice(bookPrice);	
		return bookRepository.saveAndFlush(book);
	}
	
	public String deleteBook(int bid) throws ResourceNotFoundException
	{
		getBookById(bid);
		bookRepository.deleteById(bid);
		return "Book Deleted with Id "+bid;
		
	}
	
	public List<Book> getBooks()
	{
		return bookRepository.findAll();
	}
	public List<Book> getBooksByTitleName(String titleName)
	{
		return bookRepository.getBooksByTitleName(titleName);
	}
	
	public List<Book> getBooksByAuthorName(String authorName)
	{
		return bookRepository.getBooksByAuthorName(authorName);
	}
	
	public List<Book> getBooksByPublisherName(String publisherName)
	{
		return bookRepository.getBooksByPublisherName(publisherName);
	}

	
	public List<Book> getBooksPriceLessThan(int priceRange)
	{
		return bookRepository.findByBookPriceLessThan(priceRange);
	}
	
	public List<Book> getBooksSortedByPrice()
	{
		return bookRepository.findAll(Sort.by(Direction.ASC,"bookPrice"));
	}
	
}
