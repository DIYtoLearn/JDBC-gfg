package com.gl.magicofbooks.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gl.magicofbooks.entity.Book;
import com.gl.magicofbooks.exceptions.ResourceNotFoundException;
import com.gl.magicofbooks.service.BookService;

@RestController
@RequestMapping("/admin")
public class AdminApiController
{
	@Autowired
	BookService bookservice;
	
	@PostMapping("/books/add")
	public ResponseEntity<Book> addBook(@RequestBody Book book)
	{
		Book resBook = bookservice.addBook(book);
		return  new ResponseEntity<Book>(resBook,HttpStatus.CREATED);
	}
	
	@PutMapping("/books/{bookId}")
	public ResponseEntity<Book> updateBook(@PathVariable int bookId,@RequestParam("newPrice") String newPrice)
	{
		int price = Integer.parseInt(newPrice);
		ResponseEntity<Book> res=null;
		Book book=null;
		try
		{
			book = bookservice.updateBook(bookId, price);
			res=new ResponseEntity<Book>(book,HttpStatus.OK);
			
		}catch(ResourceNotFoundException e)
		{
			res=new ResponseEntity<Book>(book,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return res;
			
	}
	
	@DeleteMapping("/books/{bookId}")
	public String deleteBook(@PathVariable int bookId)
	{
		return bookservice.deleteBook(bookId);
	}
	
	@GetMapping("/books")
	public List<Book> getAllBooks()
	{
		return bookservice.getBooks();
	}
	
	@GetMapping("/books/{bookId}")
	public ResponseEntity<Book> getBookById(@PathVariable int bookId)
	{
		Book book=bookservice.getBookById(bookId);
		return new ResponseEntity<Book>(book,HttpStatus.OK);
	}
	
	@GetMapping("books/author/{authorName}")
	public List<Book> getBookByAuthorName(@PathVariable String authorName)
	{
		return bookservice.getBooksByAuthorName(authorName);
	}
	
}
