package com.gl.magicofbooks;

//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

//import com.gl.magicofbooks.repository.UserRepository;

@SpringBootTest
class MoB6ApplicationTests {

//	@Autowired
//	UserRepository userRepoTest;
//	@Test
//	void validateUserTest()
//	{
//		System.out.println(userRepoTest.findUserbyuserNameAndpassword("sath", "sath").);
//	}

}
