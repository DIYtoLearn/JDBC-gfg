package com.gl.magicofbooks;

//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
//
//import com.gl.magicofbooks.entity.Book;
//import com.gl.magicofbooks.repository.BookRepository;
//import com.gl.magicofbooks.service.BookService;


@SpringBootTest
public class BookRepoTest
{
//	@Autowired
//	BookService bookRepoTest;
//	
//	@Test
//	public void getBookByTitleTest()
//	{
//		List<Book> books=bookRepoTest.getBooksByTitleName("rgukt");
//		System.out.println(books);
//	}
//	
//	@Test
//	public void getBookByAuthorTest()
//	{
//		List<Book> books=bookRepoTest.getBooksByAuthorName("Archer Jeffery");
//		System.out.println(books);
//	}
//	
//	@Test
//	public void getBookByPublisherTest()
//	{
//		List<Book> books=bookRepoTest.getBooksByPublisherName("Penguin");
//		System.out.println(books);
//	}
//	
//	@Test
//	public void getBooksFilterPriceRangeTest()
//	{
////		List<Book> books=bookRepoTest.findByBookPriceLessThan(200);
////		System.out.println(books);
//	}
//	
//	
//	@Test
//	public void getBookPriceFilter()
//	{
//		List<Book> books=bookRepoTest.getBooksSortedByPrice();
//		System.out.println("Sorting -> "+books);
//	}
//	
//	@Test
//	public void updateBookTest()
//	{
//		bookRepoTest.updateBook(1,249);
//		Optional<Book> book = bookRepoTest.getBookById(1);
//		System.out.println(book);
//	}
}
