package com.gl.magicofbooks.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gl.magicofbooks.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer>
{
	@Query(value="SELECT b FROM Book b WHERE b.bookName LIKE %?1%")
	List<Book> getBooksByTitleName(String bookTitle);
	
	@Query("SELECT b FROM Book b where b.bookAuthor LIKE %:authorName%")
	List<Book> getBooksByAuthorName(@Param("authorName") String authorName);
	
	@Query("SELECT b FROM Book b WHERE b.publisherName LIKE ?1")
	List<Book> getBooksByPublisherName(String publisherName);
	
	
	List<Book> findByBookPriceLessThan(int price);
	
	@Modifying
	@Transactional
	@Query("UPDATE Book b SET b.bookPrice=?2 WHERE b.bookId=?1")
	void updateBook(int bid,int bookPrice);
	
	
}
