package com.gl.magicofbooks.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.magicofbooks.entity.Book;
import com.gl.magicofbooks.service.BookService;

@RestController
@RequestMapping("/user")
public class UserApiController
{
	@Autowired
	BookService bookService;
	
	@GetMapping("/books")
	public List<Book> getAllBooks()
	{
		return bookService.getBooks();
	}
	
	@GetMapping("books/title={bookTitle}")
	public List<Book> booksByTitleName(@PathVariable String bookTitle)
	{
		return bookService.getBooksByTitleName(bookTitle);
	}
	
	@GetMapping("books/author={authorName}")
	public List<Book> BooksByAuthorName(@PathVariable String authorName)
	{
		return bookService.getBooksByAuthorName(authorName);
	}
	
	@GetMapping("books/publisher={publisherName}")
	public List<Book> getBooksByPublisherName(@PathVariable String publisherName)
	{
		return bookService.getBooksByPublisherName(publisherName);
	}
	
	@GetMapping("books/{bid}")
	public Book getBookById(@PathVariable int bid)
	{
		return bookService.getBookById(bid);
	}
	
	@GetMapping("books/price_range={priceRange}")
	public List<Book> getBooksLessThanPrice(@PathVariable int priceRange)
	{
		return bookService.getBooksPriceLessThan(priceRange);
	}
	
	@GetMapping("books/sort")
	public List<Book> getBooksSortedAscending()
	{
		return bookService.getBooksSortedByPrice();
	}
}
